package study.my.module3

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedInputStream
import java.io.IOException
import java.net.URL


class MainActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun testclick(view: View) {
//        представление xml в kotlin
        val editText: EditText = findViewById(R.id.editText)
        val string = editText.getText().toString()
        if (string == null || string.equals("")) {
            Toast.makeText(this, "Введите текст", Toast.LENGTH_SHORT).show()
        }
        var imageView: ImageView = findViewById(R.id.imageView)

        try {
            val url = URL(string)
            val inputStream = BufferedInputStream(url.openStream())
            val b: Bitmap = BitmapFactory.decodeStream(inputStream)
            imageView.setImageBitmap(b)
        } catch (e: Exception) {
            e.message
        }
    }
}